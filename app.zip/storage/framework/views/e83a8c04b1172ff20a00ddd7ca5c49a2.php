<?php $__env->startSection('content'); ?>
<div class="w-[90vw] flex items-center justify-center mt-[140px] m-auto">
    <div class="flex flex-col w-full gap-[20px]">
        <!-- Breadcrumbs -->
        <div class="flex gap-[10px] items-center">
            <a class="text-[16px] text-blue underline hover:text-green transition-all duration-500 ease-out" href="<?php echo e(route('admin.dashboard')); ?>">🡠 Volver</a>
        </div>

        <!-- Buyers -->
        <div class="border-[0.5px] border-blue border-opacity-50 rounded-[16px] p-6">
            <h3 class="font-semibold text-[22px] mb-4 text-blue">Solicitudes</h3>
            <table class="text-left w-full">
                <thead class="border-b border-blue border-opacity-50">
                    <tr class="text-[16px] font-medium text-blue">
                        <th class="py-[10px]">Nombre</th>
                        <th>Apellidos</th>
                        <th>Usuario</th>
                        <th>Teléfono</th>
                        <th>Email</th>
                        <th>Dirección de Residencia</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="py-[5px]"><?php echo e($application->buyer->name); ?></td>
                        <td><?php echo e($application->buyer->lastname); ?></td>
                        <td><?php echo e($application->buyer->username); ?></td>
                        <td>+506 <?php echo e($application->buyer->phone); ?></td>
                        <td><?php echo e($application->buyer->email); ?></td>
                        <td><?php echo e($application->residence_address); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.aplicationDetails', $application->buyer->id)); ?>"  class="text-green underline text-[16px] font-light">
                                Ver
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Ticolancer-Desarrollo\resources\views/admin/application.blade.php ENDPATH**/ ?>