<?php $__env->startSection('content'); ?>
<div class="flex flex-col justify-center items-center px-[120px] gap-[20px] max-sm:w-[90vw] max-sm:px-0 max-sm:m-auto mt-[80px]">
    <h1 class="text-blue w-fit text-[36px] font-light">Dashboard del comprador</h1>
    
    <?php if(Auth::guard('buyers')->check()): ?>
        <h2>Bienvenido (a), <?php echo e(Auth::guard('buyers')->user()->name); ?></h2> 
        <p>Cuenta: <?php echo e(Auth::guard('buyers')->user()->email); ?></p>  
        <p>Usuario: <?php echo e(Auth::guard('buyers')->user()->username); ?></p> 
        <p>Telefono: <?php echo e(Auth::guard('buyers')->user()->phone); ?></p>    
    <?php endif; ?>

    <form action="<?php echo e(route('login.logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit">Cerrar sesión</button>
    </form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('ticolancer.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Ticolancer-Desarrollo\resources\views/ticolancer/buyerDashboard.blade.php ENDPATH**/ ?>